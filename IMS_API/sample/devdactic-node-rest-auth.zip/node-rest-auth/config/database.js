module.exports = {
  'secret': 'devdacticIsAwesome',
  'database': 'mongodb://localhost/node-rest-auth'
};
